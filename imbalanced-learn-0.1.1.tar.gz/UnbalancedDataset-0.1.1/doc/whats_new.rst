.. currentmodule:: imbalanced-learn

.. _changes_0_1:

===============
Release history
===============

Version 0.1
===========

Changelog
---------

- First release of the stable API.
