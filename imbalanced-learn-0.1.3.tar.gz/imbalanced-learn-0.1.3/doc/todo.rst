.. currentmodule:: imbalanced-learn

.. _todo_0_2:

==========
To Do list
==========

Version 0.2
-----------

New methods
~~~~~~~~~~~

* AIIKNN_: Garcia, Salvador, et al. "Prototype selection for nearest neighbor classification: Taxonomy and empirical study." IEEE Transactions on Pattern Analysis and Machine Intelligence 34.3 (2012): 417-435.

.. _AIIKNN: https://www.semanticscholar.org/paper/Prototype-Selection-for-Nearest-Neighbor-Garc%C3%ADa-Derrac/fbca1824c49e02da37e5e780eaf0ab6ddfaf5614/pdf
